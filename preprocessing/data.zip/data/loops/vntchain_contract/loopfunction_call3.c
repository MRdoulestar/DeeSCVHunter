#include "vntlib.h"

constructor Test1(){}

MUTABLE
uint32 test1(uint256 amount){
    uint32 v = amount;
    uint32 c = test1(v);
    return c;
}





#include "vntlib.h"

KEY uint256 count = 0;
KEY string ss = "qian";

constructor While3(){
}

MUTABLE
uint256 test2(bool isDone){
     PrintStr("while()", "while()");

     while(count < 3) {
        if(isDone) {
            continue;
        }
        count++;
     }
     return count;
}
 
MUTABLE
uint256 test1(string s){
    int32 isDone = Equal(s, ss);
    uint32 res = test2(isDone);
    return res;
}



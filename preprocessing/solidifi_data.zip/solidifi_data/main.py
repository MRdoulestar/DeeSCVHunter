import os
import re
# 使用python-solidity-parser
import pprint
from solidity_parser import parser
import warnings
import pickle 
from util import *
import pickle
import random
warnings.filterwarnings('ignore')

# 从各个漏洞模式的func生成智能合约sol 方便后续直接解析变量等
genSolFromTemplate('Overflow-Underflow')
genSolFromTemplate('TOD')
genSolFromTemplate('tx-origin')
genSolFromTemplate('Unchecked-Send')
genSolFromTemplate('Unhandled-Exceptions')


# # with open('../train_data/data_timestamp.pkl','rb') as f:
# with open('../train_data/data_reentrancy.pkl','rb') as f:
# 	data = pickle.load(f)

# # 找出标签为0的无漏洞函数
# goods = []
# for i in data['good']:
# 	vars = i['funcvars']
# 	params = i['funcparams']
# 	if len(vars) == 0 and len(params) == 0:
# 		continue
# 	goods.append( mapping(i) )

# random.seed(2021)
# goods = random.sample(goods, 42)
# # print(goods[0])
# # exit()

# # vultype = 'Re-entrancy'
# # vultype = 'Timestamp-Dependency'
# solTrainPath = './' + vultype + '-sol/'
# solFiles = os.listdir(solTrainPath)
# bads = []
# for solFile in solFiles:
# 	# print(solFile)
# 	samples = parseSOL(solTrainPath + solFile)
# 	# 切片 可以不必要 先用全部函数进行训练
# 	# samples = getSeSlice(samples, 'block.timestamp')
# 	# print(samples[0]['funcSeSlice'])

# 	# 替换变量,参数操作
# 	for k,sample in enumerate(samples):
# 		functokens = []
# 		for line in sample['funcbody']:
# 			functokens.append(tokenize(line))
# 		samples[k]['tokens'] = functokens
# 		samples[k]['filename'] = solTrainPath + solFile
# 		# 对行的token进行标准化 避免标准化出现错误  如st->VAR0 state->VAR0ate
# 		samples[k] = mapping(samples[k])
# 	# print(samples[0])
# 	bads.append(samples[0])

# print(len(goods))
# print(len(bads))

# result = {'bad': bads, 'good': goods}
# with open('solidifi_reentrancy.pkl', 'wb') as f:
# 	pickle.dump(result, f)


from solidity_parser import parser
import re
import os

# Token handle
def isphor(s, liter):
    m = re.search(liter,s)
    if m is not None:
        return True
    else: 
        return False
def doubisphor(forward, back):
    double = ('->','--','-=','+=','++','>=','<=','==','!=','*=','/=','%=','/=','&=','^=','||','&&','>>','<<')
    string=forward+back
    
    if string in double:
        return True
    else:  
        return False
    
def trisphor(s,t):
    if (s=='>>')|(s=='<<')and(t=='='):
        return True
    else:
        return False
# 分词
def tokenize(sentence):
    formal='^[_a-zA-Z][_a-zA-Z0-9]*$'
    phla='[^_a-zA-Z0-9]'
    space='\s'
    spa=''
    string=[]
    j=0
    str = sentence
    i=0
    
    while(i<len(str)):
        if isphor(str[i],space):
            if i>j:
                string.append(str[j:i])
                j=i+1
            else:
                j=i+1
                
        elif isphor(str[i],phla):    
            if (i+1<len(str))and isphor(str[i+1],phla):
                m=doubisphor(str[i],str[i+1])
                
                if m:
                    string1=str[i]+str[i+1]
                    
                    if (i+2<len(str)) and (isphor(str[i+2],phla)):
                        if trisphor(string1,str[i+2]):
                            string.append(str[j:i])
                            string.append(str[i]+str[i+1]+str[i+2])
                            j=i+3
                            i=i+2
                            
                        else:
                            string.append(str[j:i])
                            string.append(str[i]+str[i+1])
                            string.append(str[i+2])
                            j=i+3
                            i=i+2
                            
                    else:
                        string.append(str[j:i])
                        string.append(str[i]+str[i+1])
                        j=i+2
                        i=i+1
                        
                else:
                    string.append(str[j:i])
                    string.append(str[i])
                    string.append(str[i+1])
                    j=i+2
                    i=i+1
                    
            else:
                string.append(str[j:i])
                string.append(str[i])
                j=i+1
                
        i=i+1
        
    count=0
    count1=0
    sub0='\r'
    
    if sub0 in string:
        string.remove('\r')
        
    for sub1 in string:
        if sub1==' ':
            count1=count1+1
            
    for j in range(count1):
        string.remove(' ')
        
    for sub in string:
        if sub==spa:
            count=count+1
            
    for i in range(count):
        string.remove('')
        
    return string

# split all functions of contracts
def my_split_function(filepath):
    function_list = []
    f = open(filepath, 'r', encoding='utf-8')
    lines = f.readlines()
    f.close()
    flag = -1

    for line in lines:
        text = line.strip()
        if len(text) > 0 and text != "\n":
#             if text.split()[0] == "function" or text.split()[0] == "constructor":
            if text.split()[0] == "function":
                function_list.append([text])
                flag += 1
                left_kh = 0
                right_kh = 0
                if '{' in text:
                    left_kh += 1
#             elif len(function_list) > 0 and ("function" or "constructor" in function_list[flag][0]):
            elif len(function_list) > 0 and ("function" in function_list[flag][0]):
                if right_kh == left_kh:
                    continue
                if '{' in text:
                    left_kh += 1
                elif '}' in text:
                    right_kh += 1
                function_list[flag].append(text)
                

    return function_list


# 传入sol文件名 解析所有函数
# [ {'funcname':funcName, 'funcbody':local_bodys, 'funcparams':funcParams, 'funcvars':funcVars} ]
def parseSOL(sol):
    result = []
    
#   用py-ast解析文件中所有contract
    sourceUnit = parser.parse_file(sol)
    sourceUnitObject = parser.objectify(sourceUnit)
    contracts = sourceUnitObject.contracts
    
#   切分得到所有函数
    allFunctionList = my_split_function(sol)
#   遍历所有函数
    for i in range(len(allFunctionList)):
        local_bodys = []
        funcParams = []
        funcVars = []
        funcName = ''
        for j in range(len(allFunctionList[i])):
            text = allFunctionList[i][j]
            local_bodys.append(text)
            # get the function name
            try:
                tmp = re.compile(r'\b([_A-Za-z]\w*)\b(?:(?=\s*\w+\()|(?!\s*\w+))')
                result_withdraw = tmp.findall(allFunctionList[i][0])
                funcName = result_withdraw[1]
            except Exception as e:
                print('Get funcName error.')
                continue
        if funcName == '':
            continue
        #   提取参数和局部变量
        for contract in contracts:
            functions = contracts[contract].functions.keys()
            for function in functions:
                if function == funcName:
        #           print(contracts[contract].functions[function].arguments.keys())
                    declarations = contracts[contract].functions[function].declarations
        #           print( declarations.keys() )
                    funcParams += [dec for dec in declarations.keys() if declarations[dec]['type'] == 'Parameter']
                    funcVars += [dec for dec in declarations.keys() if declarations[dec]['type'] == 'VariableDeclaration']
        funcItem = {'funcname':funcName, 'funcbody':local_bodys, 'funcparams':funcParams, 'funcvars':funcVars}
        result.append(funcItem)
        
    return result


# 根据关键搜索词找出所有样本函数
def getSamples(funcs, search):
    samples = []
    for k,func in enumerate(funcs):
        for line in func['funcbody']:
            if search in line:
                samples.append(func)
                break
    return samples


# 获得一个sample的SeSlice的具体实现
# {'funcname':funcName, 'funcbody':local_bodys, 'funcparams':funcParams, 'funcvars':funcVars}
# {'funcname':funcName, 'funcbody':local_bodys, 'funcparams':funcParams, 'funcvars':funcVars, 'funcSeSlice':funcSeSlice}
def getSeSliceImpl(sample, search):
    # print(sample['funcparams'], sample['funcvars'])
    params = list(filter(None,sample['funcparams']))
    vars = list(filter(None,sample['funcvars']))
    
    # 所有行数
    line_num = len(sample['funcbody'])
    critical_index = -1
    skip_dataflow_flag = False
    
    # line_inds存储了SeSlice的index
    line_inds = []
    # 找到切片准则对应行
    for k,v in enumerate(sample['funcbody']):
        if search in v:
            critical_index = k
            tks = tokenize(v)
            if list( set(tks) & set(vars) ) == [] and list( set(tks) & set(params) ) == []:
                skip_dataflow_flag = True
            
    # 将切片准则行序号 写入SeSlice
    line_inds.append(critical_index)
    # 默认将函数头部作为一部分
    line_inds.append(0)
    
    # 如果没有找到有变量的切片准则  跳过数据流筛选
    if critical_index == -1:
        print('No SySlice ...')
        return False
    
    # 数据流筛选  向前找相关行（后向切片）
    def DataFlowRecur(lines, index, ses_params=[], ses_vars=[]):
        # 获得其中出现的变量/参数
#         print(index)
#         print(lines[index])
        tks = tokenize(lines[index])
        for var in vars:
            if var in tks:
                ses_vars.append(var)
        for param in params:
            if param in tks:
                ses_params.append(param)
        ses_params = list(set(ses_params))
        ses_vars = list(set(ses_vars))
        
#         print(ses_vars, ses_params)
        # 返回
        if len(lines) <= 1:
#             print('Out !!!')
            return True
        
        # 每一行看是否存在数据依赖  递归
        for k,v in enumerate(lines):
            tks = tokenize(v)
            if (len( list( set(tks) - set(ses_vars) ) ) > 0) or (len( list( set(tks) - set(ses_params) ) ) > 0):
                if k not in line_inds:
                    line_inds.append(k)
                    DataFlowRecur(lines[:k+1], k, ses_params, ses_vars)

    if not skip_dataflow_flag:
        # 递归找数据依赖
        DataFlowRecur(sample['funcbody'][:critical_index+1], critical_index)

    # 去重
    line_inds = list( set(line_inds) )
#     print(line_inds)
    
    
    # 控制流筛选
    def getCtrl(funcbody, inds):
        new_inds = []
        # 逐个ind判断是否在控制流中
        for ind in inds:
            # 遍历ind之前的行
            if_flag = False
            left = 0
            right = 0
            if_ind = -1
            for k, line in enumerate(funcbody[:ind+1]):
                if 'if' in line:
                    if_flag = True
                    if_ind = k
                if if_flag:
                    if '{' in line:
                        left += 1
                    if '}' in line:
                        right += 1

            # 有影响的控制流行
            if if_flag and left > right:
                new_inds.append(if_ind)
                
        return new_inds

    
    # 数据流筛选的句子 判断数据流筛选出来的语句  是否有控制流关系
    new_inds = getCtrl(sample['funcbody'], line_inds)
    # 加入控制流SeSlice行索引
    line_inds += new_inds

    # 去重
    line_inds = list( set(line_inds) )
#     print(line_inds)
    
    # 排序 获得SeSlice
    sample['funcSeSlice'] = []
    for k,v in enumerate(sample['funcbody']):
        if k in line_inds:
            sample['funcSeSlice'].append(v)
            
    
    return sample
    


# 提取SeSlice
# 首先判断 SySlice是否在循环/条件语句中
# 接着根据数据流/控制流切片
# 如果SySlice中没有参数/局部变量 不切片 保留全部函数
def getSeSlice(samples, search):
    g_samples = []
    for k, item in enumerate(samples):
        new_item = getSeSliceImpl(item, search)
        g_samples.append(new_item)
#         print(new_item['funcSeSlice'])
    return g_samples




# 对变量进行映射
# ['filename', 'funcname', 'funcbody', 'funcparams', 'funcvars', 'tokens']
# 处理参数和变量中None的情况
def mapping(sample):
    # funcparams funcvars
    params = list(filter(None,sample['funcparams']))
    vars = list(filter(None,sample['funcvars']))
    # 处理普通funcBody
    for ind,line in enumerate(sample['tokens']):
        for _,param in enumerate(params):
            sample['tokens'][ind] = [ token.replace(param, 'PARAM'+str(_)) if token == param else token  for token in sample['tokens'][ind] ]
        for _,var in enumerate(vars):
            sample['tokens'][ind] = [ token.replace(var, 'VAR'+str(_)) if token == var else token for token in sample['tokens'][ind] ]
    # 处理SeSlice
    # for ind,line in enumerate(sample['SeSlicetokens']):
    #     for _,param in enumerate(params):
    #         sample['SeSlicetokens'][ind] = [ token.replace(param, 'PARAM'+str(_)) if token == param else token  for token in sample['SeSlicetokens'][ind] ]
    #     for _,var in enumerate(vars):
    #         sample['SeSlicetokens'][ind] = [ token.replace(var, 'VAR'+str(_)) if token == var else token for token in sample['SeSlicetokens'][ind] ]
    
    return sample
        



# 从各个漏洞模式的func生成智能合约sol 方便后续直接解析变量等
def genSolFromTemplate(vultype):
    # vultype = 'Re-entrancy'
    # vultype = 'Timestamp-Dependency'

    # 获得模板内容
    template = open('template.sol').read()
    # 提取XX类型的漏洞函数
    vulfuncPath = './' + vultype + '/'
    vulfiles = os.listdir(vulfuncPath)
    print(len(vulfiles))

    # 保存的目录
    solSavePath = './' + vultype + '-sol/'
    if not os.path.exists(solSavePath):
        os.mkdir(solSavePath)

    for i in vulfiles:
        print(i)
        vulfuncFile = vulfuncPath + i
        paddingStr = open(vulfuncFile).read()
        newSoldata = template.replace('########', paddingStr)
        outputSolName = i.replace('.txt', '-vul.sol')
        with open(solSavePath + outputSolName, 'w') as f:
            f.write(newSoldata)


